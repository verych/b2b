self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "eee83a6cd7300cce54ccd62cae082395",
    "url": "/b2b/index.html"
  },
  {
    "revision": "89a32c8f739ba7f8d769",
    "url": "/b2b/static/css/2.d0176e96.chunk.css"
  },
  {
    "revision": "4fb4a4ec4cf46947c3aa",
    "url": "/b2b/static/css/main.0ac1ac59.chunk.css"
  },
  {
    "revision": "89a32c8f739ba7f8d769",
    "url": "/b2b/static/js/2.d6bccd5b.chunk.js"
  },
  {
    "revision": "34491c6de1fbcf2388878b87785c74e7",
    "url": "/b2b/static/js/2.d6bccd5b.chunk.js.LICENSE.txt"
  },
  {
    "revision": "4fb4a4ec4cf46947c3aa",
    "url": "/b2b/static/js/main.f144d4b4.chunk.js"
  },
  {
    "revision": "102a28a506760138bc5f",
    "url": "/b2b/static/js/runtime-main.6f6ac821.js"
  },
  {
    "revision": "8880a65c57d7f031579335be153f64a0",
    "url": "/b2b/static/media/marc.8880a65c.jpg"
  },
  {
    "revision": "8e9f0a3c5578a20733d5bad0e51c91fb",
    "url": "/b2b/static/media/sidebar-1.8e9f0a3c.jpg"
  },
  {
    "revision": "310509c95512893dc661bd3a6b0d2a5d",
    "url": "/b2b/static/media/sidebar-2.310509c9.jpg"
  },
  {
    "revision": "2503169017014036cf0dd0dd7c2a2b8a",
    "url": "/b2b/static/media/sidebar-3.25031690.jpg"
  },
  {
    "revision": "fc9cb0538eb5a4dfd6fbb1bf6dd6189b",
    "url": "/b2b/static/media/sidebar-4.fc9cb053.jpg"
  }
]);