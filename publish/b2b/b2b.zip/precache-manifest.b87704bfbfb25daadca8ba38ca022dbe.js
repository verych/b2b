self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "6b4f70d206cef21921e44886fe6ccccd",
    "url": "/material-dashboard-react/index.html"
  },
  {
    "revision": "57052eb462529ec8dd4c",
    "url": "/material-dashboard-react/static/css/2.d0176e96.chunk.css"
  },
  {
    "revision": "c743eac15dbe2a988687",
    "url": "/material-dashboard-react/static/css/main.0ac1ac59.chunk.css"
  },
  {
    "revision": "57052eb462529ec8dd4c",
    "url": "/material-dashboard-react/static/js/2.29d046ab.chunk.js"
  },
  {
    "revision": "34491c6de1fbcf2388878b87785c74e7",
    "url": "/material-dashboard-react/static/js/2.29d046ab.chunk.js.LICENSE.txt"
  },
  {
    "revision": "c743eac15dbe2a988687",
    "url": "/material-dashboard-react/static/js/main.1579b055.chunk.js"
  },
  {
    "revision": "f7bdf0cfc9ea0dd44285692948c2d84f",
    "url": "/material-dashboard-react/static/js/main.1579b055.chunk.js.LICENSE.txt"
  },
  {
    "revision": "a025ab54ec03fed337bb",
    "url": "/material-dashboard-react/static/js/runtime-main.d0bf2bb1.js"
  },
  {
    "revision": "8880a65c57d7f031579335be153f64a0",
    "url": "/material-dashboard-react/static/media/marc.8880a65c.jpg"
  },
  {
    "revision": "8e9f0a3c5578a20733d5bad0e51c91fb",
    "url": "/material-dashboard-react/static/media/sidebar-1.8e9f0a3c.jpg"
  },
  {
    "revision": "310509c95512893dc661bd3a6b0d2a5d",
    "url": "/material-dashboard-react/static/media/sidebar-2.310509c9.jpg"
  },
  {
    "revision": "2503169017014036cf0dd0dd7c2a2b8a",
    "url": "/material-dashboard-react/static/media/sidebar-3.25031690.jpg"
  },
  {
    "revision": "fc9cb0538eb5a4dfd6fbb1bf6dd6189b",
    "url": "/material-dashboard-react/static/media/sidebar-4.fc9cb053.jpg"
  }
]);